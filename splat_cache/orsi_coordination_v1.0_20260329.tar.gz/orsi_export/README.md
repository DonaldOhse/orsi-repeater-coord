# Oklahoma Repeater Society — Coordination System
## ORSI Repeater Coordination System v1.0
Generated: $(date)

### Requirements
- Ubuntu 22.04+ / Debian 12+
- Apache 2.4+ with mod_rewrite
- PHP 8.1+ with PDO, PDO_MySQL
- MySQL 8.0+
- Postfix (loopback-only)
- SPLAT! v1.4.2
- ImageMagick

### Directory Structure
- repeater_coord/ — Web application root
- orsi_database.sql — Full database dump with schema and data

### Installation
Run: sudo bash install.sh

### Live Site
https://w5dro.com/repeater_coord/
