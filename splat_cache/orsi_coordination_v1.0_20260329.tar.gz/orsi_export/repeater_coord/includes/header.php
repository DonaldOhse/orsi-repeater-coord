<?php
require_once __DIR__ . '/config.php';
$user = current_user();
$flashes = get_flashes();
$page_title = $page_title ?? SITE_NAME;
$b = BASE_PATH;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($page_title) ?> — <?= SITE_SHORT ?></title>
<link rel="stylesheet" href="<?= $b ?>/assets/css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<header class="site-header">
  <div class="header-top">
    <span>Oklahoma Repeater Society, Inc. — Frequency Coordination for the State of Oklahoma</span>
    <span>Database: 18-Oct-2025 &nbsp;|&nbsp; <a href="https://oklahomarepeatersociety.org" target="_blank">ORSI Website</a></span>
  </div>
  <div class="header-inner">
    <a href="<?= $b ?>/index.php" class="brand">
      <div class="brand-logo">ORSI</div>
      <div class="brand-text">
        <div class="name">OK Repeater Coordination</div>
        <div class="sub">Oklahoma Repeater Society, Inc.</div>
      </div>
    </a>
    <nav class="main-nav">
      <a href="<?= $b ?>/index.php"><i class="fa fa-list"></i> Repeaters</a>
      <a href="<?= $b ?>/map.php"><i class="fa fa-map-marker-alt"></i> Map</a>
      <?php if (is_logged_in() && in_array($user['role'], ['admin','coordinator'])): ?>
      <a href="<?= $b ?>/conflicts.php"><i class="fa fa-triangle-exclamation"></i> Conflicts</a>
      <?php endif; ?>
      <?php if (is_logged_in() && in_array($user['role'], ['admin','coordinator'])): ?>
      <?php
      $_pending = (int)get_db()->query("SELECT COUNT(*) FROM coordination_requests WHERE status='PENDING'")->fetchColumn();
      ?>
      <a href="<?= $b ?>/admin/requests.php" style="position:relative">
        <i class="fa fa-inbox"></i> Requests
        <?php if ($_pending): ?><span style="position:absolute;top:-4px;right:-4px;background:#dc2626;color:#fff;border-radius:50%;width:16px;height:16px;font-size:.65rem;display:flex;align-items:center;justify-content:center;font-weight:700"><?= $_pending ?></span><?php endif; ?>
      </a>
      <a href="<?= $b ?>/admin/rules.php"><i class="fa fa-sliders"></i> Rules</a>
      <a href="<?= $b ?>/admin/import.php"><i class="fa fa-file-import"></i> Import</a>
      <a href="<?= $b ?>/admin/chat.php"><i class="fa fa-comments"></i> Chat</a>
      <?php endif; ?>
      <?php if (is_logged_in() && $user['role'] === 'admin'): ?>
      <a href="<?= $b ?>/admin/send_renewals.php?dry_run=1"><i class="fa fa-rotate"></i> Renewals</a>
      <a href="<?= $b ?>/admin/test_email.php"><i class="fa fa-envelope"></i> Test Email</a>
      <?php endif; ?>
      <?php if (is_logged_in() && $user['role'] === 'admin'): ?>
      <a href="<?= $b ?>/admin/users.php"><i class="fa fa-users"></i> Users</a>
      <?php endif; ?>
    </nav>
    <div class="header-user">
      <?php if (is_logged_in()): ?>
        <span><i class="fa fa-user"></i> <?= h($user['callsign'] ?: $user['username']) ?> (<?= h($user['role']) ?>)</span>
        <a href="<?= $b ?>/logout.php" class="btn btn-outline btn-sm">Log Out</a>
      <?php else: ?>
        <a href="<?= $b ?>/login.php" class="btn btn-outline btn-sm">Log In</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main class="main-content">
<?php if ($flashes): foreach ($flashes as $f): ?>
<div class="alert alert-<?= h($f['type']) ?>">
  <i class="fa fa-<?= $f['type']==='success'?'check-circle':($f['type']==='danger'?'exclamation-circle':'info-circle') ?>"></i>
  <?= h($f['msg']) ?>
</div>
<?php endforeach; endif; ?>
