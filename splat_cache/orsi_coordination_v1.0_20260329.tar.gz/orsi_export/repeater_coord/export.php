<?php
require_once __DIR__ . '/includes/config.php';
$db = get_db();

// Build same filters as index.php
$where  = ['1=1'];
$params = [];
foreach (['district','type','status','county'] as $col) {
    if (!empty($_GET[$col])) { $where[] = "$col = ?"; $params[] = $_GET[$col]; }
}
if (!empty($_GET['search'])) {
    $s = '%' . $_GET['search'] . '%';
    $where[] = "(callsign LIKE ? OR trustee LIKE ? OR sponsor LIKE ? OR city LIKE ? OR county LIKE ?)";
    $params  = array_merge($params, [$s,$s,$s,$s,$s]);
}
if (!empty($_GET['freq_min'])) { $where[] = 'output_freq >= ?'; $params[] = (float)$_GET['freq_min']; }
if (!empty($_GET['freq_max'])) { $where[] = 'output_freq <= ?'; $params[] = (float)$_GET['freq_max']; }

$stmt = $db->prepare("SELECT district,type,status,output_freq,input_freq,callsign,trustee,sponsor,county,city,pl_tone,open_system,autopatch,closed_autopatch,skywarn,linked,internet_link,date_coordinated,last_update,url,notes FROM repeaters WHERE " . implode(' AND ',$where) . " ORDER BY output_freq");
$stmt->execute($params);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="OK_Repeaters_' . date('Ymd') . '.csv"');

$out = fopen('php://output','w');
fputcsv($out,['ORSI District','TYPE','SYSTEM STATUS','OUTPUT','INPUT','RPTR CALL','TRUSTEE','SPONSOR','COUNTY','CITY','PL TONE','OPEN SYSTEM','AUTO-PATCH','CLOSED AUTO-PATCH','SKYWARN?','LINKED?','INTERNETLINK','DATE COORDINATED','LAST UPDATE','URL','NOTES']);
while ($row = $stmt->fetch()) {
    fputcsv($out, array_values($row));
}
fclose($out);
exit;
