<?php
require_once __DIR__ . '/../includes/config.php';
$db = get_db();

// Can be run from browser by admins or from cron
$is_cron = php_sapi_name() === 'cli';
if (!$is_cron) {
    require_role('admin');
    $page_title = 'Send Renewal Notices';
    include __DIR__ . '/../includes/header.php';
}

$dry_run = isset($_GET['dry_run']) || (isset($argv[1]) && $argv[1] === '--dry-run');

// ── NOPC: Send 48hr reminders and mark 72hr no-responses ────
$nopc_pending = $db->query("SELECT n.*, r.applicant_callsign, r.suggested_freq, r.preferred_freq, r.city, r.county, r.req_band, r.id as req_id FROM nopc_notifications n JOIN coordination_requests r ON r.id = n.request_id WHERE n.status = 'PENDING'")->fetchAll();

foreach ($nopc_pending as $n) {
    $hours_since = (time() - strtotime($n['sent_at'])) / 3600;
    $hours_left  = (strtotime($n['expires_at']) - time()) / 3600;

    // Send 48hr reminder
    if ($hours_since >= 48 && !$n['reminder_sent'] && $hours_left > 0) {
        if (!$dry_run) {
            $approve_url = "https://w5dro.com/repeater_coord/nopc_response.php?token={$n['token']}&action=approve";
            $decline_url = "https://w5dro.com/repeater_coord/nopc_response.php?token={$n['token']}&action=decline";
            $subject = "REMINDER: NOPC Response Required — {$n['applicant_callsign']} {$n['suggested_freq']} MHz";
            $body  = "REMINDER — 24 hours remaining to respond\n\n";
            $body .= "This is a reminder that your response is needed for the following NOPC within 24 hours.\n\n";
            $body .= "Repeater: {$n['applicant_callsign']} — {$n['suggested_freq']} MHz\n";
            $body .= "Location: {$n['city']}, {$n['county']} County, Oklahoma\n";
            $body .= "Deadline: " . date('Y-m-d H:i', strtotime($n['expires_at'])) . "\n\n";
            $body .= "APPROVE: {$approve_url}\n\nDECLINE: {$decline_url}\n\n73,\nOklahoma Repeater Society\n";
            mail($n['contact_email'], $subject, $body, "From: ORSI Coordination <noreply@w5dro.com>");
            $db->prepare("UPDATE nopc_notifications SET reminder_sent=1, reminder_sent_at=NOW() WHERE id=?")->execute([$n['id']]);
        }
        echo date('Y-m-d H:i:s') . " NOPC reminder sent to {$n['state']} for {$n['applicant_callsign']}\n";
    }

    // Auto-proceed after 72hrs
    if ($hours_left <= 0) {
        if (!$dry_run) {
            $db->prepare("UPDATE nopc_notifications SET status='NO_RESPONSE', response_at=NOW() WHERE id=?")->execute([$n['id']]);
            // Notify OK coordinators
            $all_emails = get_all_coordinator_emails('OKC');
            $subject = "NOPC No Response — {$n['state']} — Proceed with {$n['applicant_callsign']} {$n['suggested_freq']} MHz";
            $body  = "The 72-hour NOPC window has expired with no response from {$n['state']}.\n\n";
            $body .= "Per coordination guidelines, you may proceed with this coordination.\n\n";
            $body .= "Repeater: {$n['applicant_callsign']} — {$n['suggested_freq']} MHz\n";
            $body .= "Location: {$n['city']}, {$n['county']} County, Oklahoma\n";
            $body .= "NOPC Sent: " . substr($n['sent_at'],0,10) . "\n";
            $body .= "Expired:   " . substr($n['expires_at'],0,10) . "\n\n";
            $body .= "View request:\nhttps://w5dro.com/repeater_coord/admin/requests.php?id={$n['req_id']}\n\n73,\nORSI System\n";
            foreach ($all_emails as $email) {
                mail($email, $subject, $body, "From: ORSI Coordination <noreply@w5dro.com>");
            }
        }
        echo date('Y-m-d H:i:s') . " NOPC expired — {$n['state']} no response for {$n['applicant_callsign']}\n";
    }
}

// ── Mark repeaters as Unknown after 5 years without renewal ──
// Only mark UNKNOWN if ALL date fields are either NULL or older than 5 years
$expired = $db->query("
    SELECT id, callsign, output_freq, status, district,
           GREATEST(
               COALESCE(last_renewal_sent, '1900-01-01'),
               COALESCE(last_update,       '1900-01-01'),
               COALESCE(date_coordinated,  '1900-01-01')
           ) AS last_active
    FROM repeaters
    WHERE status = 'OPERATIONAL'
    AND COALESCE(last_renewal_sent, '1900-01-01') < DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
    AND COALESCE(last_update,       '1900-01-01') < DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
    AND COALESCE(date_coordinated,  '1900-01-01') < DATE_SUB(CURDATE(), INTERVAL 5 YEAR)
    AND private = 0
")->fetchAll();

$marked_unknown = 0;
foreach ($expired as $r) {
    if (!$dry_run) {
        $db->prepare("UPDATE repeaters SET status='UNKNOWN', last_update=CURDATE() WHERE id=?")->execute([$r['id']]);
        audit('AUTO_STATUS', 'repeaters', $r['id'], ['status'=>'OPERATIONAL'], ['status'=>'UNKNOWN', 'reason'=>'No renewal in 5 years']);

        // Notify coordinator
        $coord_email = get_coordinator_email($r['district'] ?? 'OKC');
        if ($coord_email) {
            mail($coord_email,
                "Auto-Status Change: {$r['callsign']} moved to UNKNOWN",
                "The following repeater has been automatically moved to UNKNOWN status due to no renewal in 5 years:\n\n" .
                "Callsign: {$r['callsign']}\nFrequency: {$r['output_freq']} MHz\nLast Active: {$r['last_active']}\n\n" .
                "View: https://w5dro.com/repeater_coord/repeater.php?id={$r['id']}\n\n73,\nORSI System",
                "From: ORSI Coordination <noreply@w5dro.com>"
            );
        }
    }
    $marked_unknown++;
}

// ── Send annual renewal emails ────────────────────────────────
// Target: operational repeaters not renewed in 11+ months
$due = $db->query("
    SELECT r.*, c.contact_email
    FROM repeaters r
    LEFT JOIN repeaters c ON c.id = r.id
    WHERE r.status IN ('OPERATIONAL','DOWN TEMPORARILY')
    AND r.private = 0
    AND r.contact_email IS NOT NULL
    AND r.contact_email != ''
    AND (r.last_renewal_sent IS NULL OR r.last_renewal_sent < DATE_SUB(CURDATE(), INTERVAL 11 MONTH))
    LIMIT 50
")->fetchAll();

$sent = 0;
$skipped = 0;
foreach ($due as $r) {
    // Generate secure token
    $token     = bin2hex(random_bytes(32));
    $token_exp = date('Y-m-d', strtotime('+30 days'));

    if (!$dry_run) {
        $db->prepare("UPDATE repeaters SET renewal_token=?, renewal_token_exp=?, last_renewal_sent=CURDATE() WHERE id=?")
           ->execute([$token, $token_exp, $r['id']]);
    }

    $renewal_url = "https://w5dro.com/repeater_coord/renewal.php?token={$token}";
    $body  = "Dear {$r['callsign']} Trustee,\n\n";
    $body .= "This is your annual renewal notice for your coordinated repeater listing with the Oklahoma Repeater Society.\n\n";
    $body .= "Repeater: {$r['callsign']} — {$r['output_freq']} MHz\n";
    $body .= "Location: {$r['city']}, {$r['county']} County\n";
    $body .= "Status:   {$r['status']}\n\n";
    $body .= "Please click the link below to review and confirm your listing is current:\n\n";
    $body .= "{$renewal_url}\n\n";
    $body .= "This link expires in 30 days. If you do not renew within 5 years, your repeater\n";
    $body .= "will be automatically moved to Unknown status.\n\n";
    $body .= "If any information needs updating, you can submit changes directly from the renewal page.\n\n";
    $body .= "Thank you for keeping the ORSI database current.\n\n";
    $body .= "73,\nOklahoma Repeater Society\nhttps://oklahomarepeatersociety.org\n";

    if (!$dry_run) {
        $result = mail(
            $r['contact_email'],
            "Annual Renewal Notice — {$r['callsign']} {$r['output_freq']} MHz — ORSI",
            $body,
            "From: ORSI Coordination <noreply@w5dro.com>"
        );
        if ($result) $sent++;
        else $skipped++;
    } else {
        $sent++;
    }
}

// ── Output results ────────────────────────────────────────────
if ($is_cron) {
    echo date('Y-m-d H:i:s') . " — Renewals: sent={$sent}, skipped={$skipped}, marked_unknown={$marked_unknown}\n";
} else {
    ?>
    <div class="page-title"><i class="fa fa-rotate"></i> Annual Renewal System</div>

    <?php if ($dry_run): ?>
    <div class="alert alert-warning"><i class="fa fa-eye"></i> <strong>Dry Run</strong> — No emails sent, no statuses changed.</div>
    <?php endif; ?>

    <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);max-width:500px;margin-bottom:20px">
      <div class="stat-card green"><div class="stat-value"><?= $sent ?></div><div class="stat-label">Renewals <?= $dry_run?'Would Send':'Sent' ?></div></div>
      <div class="stat-card orange"><div class="stat-value"><?= $skipped ?></div><div class="stat-label">Failed</div></div>
      <div class="stat-card red"><div class="stat-value"><?= $marked_unknown ?></div><div class="stat-label">Moved to Unknown</div></div>
    </div>

    <?php if ($marked_unknown > 0): ?>
    <div class="alert alert-warning">
      <i class="fa fa-triangle-exclamation"></i>
      <strong><?= $marked_unknown ?> repeater<?= $marked_unknown!=1?'s':'' ?></strong> moved to UNKNOWN status — no renewal in 5+ years.
    </div>
    <?php endif; ?>

    <?php if (!$dry_run && $sent > 0): ?>
    <div class="alert alert-success">
      <i class="fa fa-envelope"></i> <?= $sent ?> renewal email<?= $sent!=1?'s':'' ?> sent successfully.
    </div>
    <?php endif; ?>

    <div class="card" style="margin-bottom:16px">
      <div class="card-header"><i class="fa fa-clock"></i> Repeaters Due for Renewal (<?= count($due) ?>)</div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>Callsign</th><th>Freq</th><th>Status</th><th>Location</th><th>Contact Email</th><th>Last Renewal</th></tr></thead>
          <tbody>
          <?php foreach ($due as $r): ?>
          <tr>
            <td><a href="<?= BASE_PATH ?>/repeater.php?id=<?= $r['id'] ?>" class="callsign-link"><?= h($r['callsign']) ?></a></td>
            <td><span class="freq"><?= number_format((float)$r['output_freq'],4) ?></span></td>
            <td><?= h($r['status']) ?></td>
            <td><?= h($r['city']) ?>, <?= h($r['county']) ?></td>
            <td><?= h($r['contact_email'] ?: '—') ?></td>
            <td><?= $r['last_renewal_sent'] ? h($r['last_renewal_sent']) : '<span class="text-muted">Never</span>' ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$due): ?>
          <tr><td colspan="6" class="text-center text-muted" style="padding:20px">No renewals due.</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <?php if ($dry_run): ?>
      <a href="<?= BASE_PATH ?>/admin/send_renewals.php" class="btn btn-success" onclick="return confirm('Send renewal emails now?')">
        <i class="fa fa-paper-plane"></i> Send Now (Live Run)
      </a>
      <?php else: ?>
      <a href="<?= BASE_PATH ?>/admin/send_renewals.php?dry_run=1" class="btn btn-secondary">
        <i class="fa fa-eye"></i> Dry Run (Preview Only)
      </a>
      <?php endif; ?>
      <a href="<?= BASE_PATH ?>/admin/send_renewals.php" class="btn btn-primary">
        <i class="fa fa-rotate"></i> Run Again
      </a>
    </div>

    <?php
    include __DIR__ . '/../includes/footer.php';
}
