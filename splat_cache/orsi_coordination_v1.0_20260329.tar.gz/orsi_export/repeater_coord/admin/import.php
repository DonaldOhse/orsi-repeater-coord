<?php
require_once __DIR__ . '/../includes/config.php';
require_role('coordinator');
$db = get_db();

$results   = [];
$errors    = [];
$imported  = 0;
$skipped   = 0;
$updated   = 0;

// ── Process Upload ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    $mode    = $_POST['import_mode'] ?? 'skip';   // skip | update | replace
    $has_hdr = !empty($_POST['has_header']);

    $tmp = $_FILES['csv_file']['tmp_name'];
    $ext = strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, ['csv','txt'])) {
        $errors[] = 'Only CSV/TXT files are supported.';
    } elseif (!is_uploaded_file($tmp)) {
        $errors[] = 'File upload failed.';
    } else {
        $handle = fopen($tmp, 'r');
        $row_num = 0;

        // Expected column order (ORSI format):
        // district, type, status, output_freq, input_freq, callsign, trustee, sponsor,
        // county, city, pl_tone, open_system, autopatch, closed_autopatch, skywarn,
        // linked, internet_link, date_coordinated, last_update, url, notes

        $col_map = [
            0=>'district', 1=>'type', 2=>'status', 3=>'output_freq', 4=>'input_freq',
            5=>'callsign', 6=>'trustee', 7=>'sponsor', 8=>'county', 9=>'city',
            10=>'pl_tone', 11=>'open_system', 12=>'autopatch', 13=>'closed_autopatch',
            14=>'skywarn', 15=>'linked', 16=>'internet_link', 17=>'date_coordinated',
            18=>'last_update', 19=>'url', 20=>'notes',
        ];

        $insert_stmt = $db->prepare("INSERT INTO repeaters (district,type,status,output_freq,input_freq,callsign,trustee,sponsor,county,city,pl_tone,open_system,autopatch,closed_autopatch,skywarn,linked,internet_link,date_coordinated,last_update,url,notes)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        $update_stmt = $db->prepare("UPDATE repeaters SET district=?,type=?,status=?,output_freq=?,input_freq=?,trustee=?,sponsor=?,county=?,city=?,pl_tone=?,open_system=?,autopatch=?,closed_autopatch=?,skywarn=?,linked=?,internet_link=?,date_coordinated=?,last_update=?,url=?,notes=? WHERE callsign=? AND output_freq=?");

        $check_stmt  = $db->prepare("SELECT id FROM repeaters WHERE callsign=? AND output_freq=?");

        if ($mode === 'replace') {
            $db->exec("TRUNCATE TABLE repeaters");
            $results[] = ['info','Existing records cleared (replace mode).'];
        }

        while (($row = fgetcsv($handle, 2000, ',')) !== false) {
            $row_num++;
            // Skip title row (first row if it contains "Oklahoma" or "ORSI")
            if ($row_num === 1 && isset($row[0]) && (stripos($row[0],'oklahoma')!==false || stripos($row[0],'ORSI')!==false)) continue;
            // Skip header row
            if ($has_hdr && $row_num <= 2 && isset($row[3]) && !is_numeric($row[3])) continue;

            if (count($row) < 5) { $skipped++; continue; }

            $d = [];
            foreach ($col_map as $ci => $cn) {
                $v = isset($row[$ci]) ? trim($row[$ci]) : '';
                if (in_array($cn, ['open_system','autopatch','closed_autopatch','skywarn','linked'])) {
                    $d[$cn] = ($v === '1') ? 1 : 0;
                } elseif (in_array($cn, ['output_freq','input_freq','pl_tone'])) {
                    $d[$cn] = is_numeric($v) ? (float)$v : null;
                } elseif (in_array($cn, ['date_coordinated','last_update'])) {
                    if ($v && preg_match('/(\d+)\/(\d+)\/(\d+)/', $v, $m)) {
                        $yr = strlen($m[3])==2 ? (int($m[3])<50?'20':'19').$m[3] : $m[3];
                        $d[$cn] = "$yr-".str_pad($m[1],2,'0',STR_PAD_LEFT).'-'.str_pad($m[2],2,'0',STR_PAD_LEFT);
                    } elseif ($v && preg_match('/\d{4}-\d{2}-\d{2}/', $v)) {
                        $d[$cn] = $v;
                    } else {
                        $d[$cn] = null;
                    }
                } else {
                    $d[$cn] = $v;
                }
            }

            if (!$d['output_freq'] || !$d['input_freq'] || !$d['callsign']) { $skipped++; continue; }

            try {
                if ($mode !== 'replace') {
                    $check_stmt->execute([$d['callsign'], $d['output_freq']]);
                    $exists = $check_stmt->fetchColumn();
                    if ($exists) {
                        if ($mode === 'update') {
                            $update_stmt->execute([
                                $d['district'],$d['type'],$d['status'],$d['output_freq'],$d['input_freq'],
                                $d['trustee'],$d['sponsor'],$d['county'],$d['city'],$d['pl_tone'],
                                $d['open_system'],$d['autopatch'],$d['closed_autopatch'],$d['skywarn'],
                                $d['linked'],$d['internet_link'],$d['date_coordinated'],$d['last_update'],
                                $d['url'],$d['notes'],
                                $d['callsign'],$d['output_freq']
                            ]);
                            $updated++;
                        } else {
                            $skipped++;
                        }
                        continue;
                    }
                }
                $insert_stmt->execute([
                    $d['district'],$d['type'],$d['status'],$d['output_freq'],$d['input_freq'],
                    $d['callsign'],$d['trustee'],$d['sponsor'],$d['county'],$d['city'],
                    $d['pl_tone'],$d['open_system'],$d['autopatch'],$d['closed_autopatch'],
                    $d['skywarn'],$d['linked'],$d['internet_link'],$d['date_coordinated'],
                    $d['last_update'],$d['url'],$d['notes'],
                ]);
                $imported++;
            } catch (PDOException $e) {
                $errors[] = "Row $row_num ({$d['callsign']}): " . $e->getMessage();
            }
        }
        fclose($handle);

        audit('IMPORT','repeaters',0,null,['imported'=>$imported,'updated'=>$updated,'skipped'=>$skipped,'mode'=>$mode]);

        if ($imported || $updated) flash('success',"Import complete: $imported inserted, $updated updated, $skipped skipped.");
        else flash('warning',"Import finished: 0 records inserted. $skipped skipped. Check for errors.");
        header('Location: ' . BASE_PATH . '/admin/import.php');
        exit;
    }
}

$total = (int)$db->query("SELECT COUNT(*) FROM repeaters")->fetchColumn();
$page_title = 'Import Repeaters';
include __DIR__ . '/../includes/header.php';
?>

<div class="page-title"><i class="fa fa-file-import"></i> Import Repeaters</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start">

<!-- Upload Form -->
<div class="card">
  <div class="card-header"><i class="fa fa-upload"></i> Upload CSV File</div>
  <div class="card-body">
    <?php foreach ($errors as $e): ?><div class="alert alert-danger"><?= h($e) ?></div><?php endforeach; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="form-group" style="margin-bottom:14px">
        <label>CSV File *</label>
        <input type="file" name="csv_file" accept=".csv,.txt" required>
        <small class="text-muted">Max <?= ini_get('upload_max_filesize') ?>. UTF-8 or Latin-1 CSV.</small>
      </div>

      <div class="form-group" style="margin-bottom:14px">
        <label>Import Mode</label>
        <select name="import_mode">
          <option value="skip">Skip duplicates (same callsign + output freq)</option>
          <option value="update">Update existing, insert new</option>
          <option value="replace">Replace ALL records (danger!)</option>
        </select>
      </div>

      <div class="form-group" style="margin-bottom:18px">
        <label class="form-check">
          <input type="checkbox" name="has_header" value="1" checked>
          File has header row (ORSI format: district, type, status, output, input…)
        </label>
      </div>

      <button type="submit" class="btn btn-primary"><i class="fa fa-file-import"></i> Import</button>
    </form>
  </div>
</div>

<!-- Format Guide -->
<div>
  <div class="card" style="margin-bottom:16px">
    <div class="card-header"><i class="fa fa-circle-info"></i> Expected CSV Format (ORSI)</div>
    <div class="card-body" style="font-size:.82rem">
      <p style="margin-bottom:10px">Columns must be in this order (or match ORSI export format):</p>
      <table style="width:100%;border-collapse:collapse;font-size:.8rem">
        <thead><tr style="background:#f4f6f8"><th style="padding:4px 8px;text-align:left">#</th><th style="padding:4px 8px;text-align:left">Column</th><th style="padding:4px 8px;text-align:left">Example</th></tr></thead>
        <tbody>
        <?php
        $cols = [
            ['ORSI District','NE'],['TYPE','REPEATER'],['SYSTEM STATUS','OPERATIONAL'],
            ['OUTPUT','146.940'],['INPUT','146.340'],['RPTR CALL','WB5XXX'],
            ['TRUSTEE','WB5XXX'],['SPONSOR','Tulsa ARC'],['COUNTY','TULSA'],
            ['CITY','Tulsa'],['PL TONE','88.5'],['OPEN SYSTEM','1'],
            ['AUTO-PATCH','0'],['CLOSED AUTO-PATCH','0'],['SKYWARN?','1'],
            ['LINKED?','0'],['INTERNETLINK','IRLP'],['DATE COORD-INATED','12/01/1980'],
            ['LAST UPDATE','10/17/2025'],['URL','https://example.com'],['NOTES','Notes here'],
        ];
        foreach ($cols as $i => $c): ?>
        <tr style="border-bottom:1px solid #eee">
          <td style="padding:3px 8px;color:var(--muted)"><?= $i ?></td>
          <td style="padding:3px 8px;font-weight:600"><?= h($c[0]) ?></td>
          <td style="padding:3px 8px;color:var(--muted);font-family:monospace"><?= h($c[1]) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-header"><i class="fa fa-database"></i> Current Database</div>
    <div class="card-body">
      <p><strong><?= number_format($total) ?></strong> repeaters currently in database.</p>
      <p style="margin-top:10px"><a href="<?= BASE_PATH ?>/export.php" class="btn btn-secondary btn-sm"><i class="fa fa-download"></i> Export All as CSV</a></p>
    </div>
  </div>
</div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
