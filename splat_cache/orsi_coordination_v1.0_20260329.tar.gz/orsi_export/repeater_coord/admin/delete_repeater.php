<?php
require_once __DIR__ . '/../includes/config.php';
require_role('admin');
$db = get_db();

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: ' . BASE_PATH . '/index.php'); exit; }

$stmt = $db->prepare("SELECT * FROM repeaters WHERE id = ?");
$stmt->execute([$id]);
$rep = $stmt->fetch();
if (!$rep) { flash('danger','Repeater not found.'); header('Location: ' . BASE_PATH . '/index.php'); exit; }

$db->prepare("DELETE FROM repeaters WHERE id = ?")->execute([$id]);
audit('DELETE','repeaters',$id,$rep,null);
flash('success', 'Repeater ' . $rep['callsign'] . ' deleted.');
header('Location: ' . BASE_PATH . '/index.php');
exit;
