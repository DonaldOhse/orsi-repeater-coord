<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/includes/config.php';

echo "<h2>Debug Login Test</h2>";

// Test DB connection
try {
    $db = get_db();
    echo "<p style='color:green'>✓ DB connected OK</p>";
} catch (Exception $e) {
    echo "<p style='color:red'>✗ DB failed: " . $e->getMessage() . "</p>";
    exit;
}

// Test user lookup
$stmt = $db->prepare("SELECT * FROM users WHERE username = 'admin' AND active = 1 LIMIT 1");
$stmt->execute();
$u = $stmt->fetch();
echo "<p>User found: " . ($u ? "<span style='color:green'>YES</span>" : "<span style='color:red'>NO</span>") . "</p>";

if ($u) {
    echo "<p>Hash in DB: " . htmlspecialchars($u['password']) . "</p>";
    $test_pw = 'Admin1234';
    $verify = password_verify($test_pw, $u['password']);
    echo "<p>password_verify('$test_pw'): " . ($verify ? "<span style='color:green'>MATCH</span>" : "<span style='color:red'>NO MATCH</span>") . "</p>";
}

// Test session
echo "<p>Session save path: " . session_save_path() . "</p>";
echo "<p>Session save path writable: " . (is_writable(session_save_path()) ? "<span style='color:green'>YES</span>" : "<span style='color:red'>NO</span>") . "</p>";

start_session();
$_SESSION['test'] = 'hello';
echo "<p>Session ID: " . session_id() . "</p>";
echo "<p>Session test value: " . ($_SESSION['test'] ?? 'NOT SET') . "</p>";

echo "<hr><p>If everything above is green, click below to test actual login:</p>";
echo "<form method='post'><input name='pw' placeholder='enter password'><button type='submit'>Test</button></form>";

if ($_POST['pw'] ?? '') {
    $verify2 = password_verify($_POST['pw'], $u['password'] ?? '');
    echo "<p>Verify result for entered password: " . ($verify2 ? "<span style='color:green'>MATCH</span>" : "<span style='color:red'>NO MATCH</span>") . "</p>";
}
