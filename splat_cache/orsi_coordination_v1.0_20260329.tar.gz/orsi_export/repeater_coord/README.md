# Oklahoma Repeater Coordination System
### Installation & Administration Guide

---

## Requirements

- Ubuntu Server (20.04 or 22.04 LTS)
- Apache 2.4+
- PHP 8.0+ with extensions: `pdo`, `pdo_mysql`, `fileinfo`, `mbstring`
- MySQL 5.7+ or MariaDB 10.3+

---

## Installation Steps

### 1. Install LAMP Stack

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install apache2 php php-mysql php-mbstring php-pdo mysql-server -y
sudo systemctl enable apache2 mysql
sudo systemctl start apache2 mysql
```

### 2. Secure MySQL

```bash
sudo mysql_secure_installation
```

### 3. Create Database & User

```bash
sudo mysql -u root -p
```

Inside MySQL:
```sql
CREATE DATABASE ok_repeater_coord CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'repeater_user'@'localhost' IDENTIFIED BY 'StrongPassword123!';
GRANT ALL PRIVILEGES ON ok_repeater_coord.* TO 'repeater_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### 4. Import the Database Schema + Data

```bash
mysql -u repeater_user -p ok_repeater_coord < /path/to/database.sql
```

This imports:
- All table structures
- 7 default coordination rules (ARRL band plan)
- All 479 ORSI repeater records (as of Oct 2025)
- 1 default admin user

### 5. Deploy Files

Copy the web files to Apache document root:

```bash
sudo cp -r repeater_coord/* /var/www/html/
sudo chown -R www-data:www-data /var/www/html/
sudo chmod -R 755 /var/www/html/
```

Or deploy to a subdirectory:
```bash
sudo mkdir -p /var/www/html/repeaters
sudo cp -r repeater_coord/* /var/www/html/repeaters/
sudo chown -R www-data:www-data /var/www/html/repeaters/
```

### 6. Configure Database Connection

Edit `/var/www/html/includes/config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'ok_repeater_coord');
define('DB_USER', 'repeater_user');
define('DB_PASS', 'StrongPassword123!');  // ← Change this!
```

### 7. Enable Apache mod_rewrite & Headers

```bash
sudo a2enmod rewrite headers expires
sudo systemctl restart apache2
```

### 8. Configure Apache VirtualHost (optional)

```apache
<VirtualHost *:80>
    ServerName repeaters.yourdomain.org
    DocumentRoot /var/www/html

    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>

    ErrorLog ${APACHE_LOG_DIR}/repeater_error.log
    CustomLog ${APACHE_LOG_DIR}/repeater_access.log combined
</VirtualHost>
```

### 9. First Login

Navigate to `http://your-server/` and log in:

- **Username:** `admin`
- **Password:** `Admin@1234`

⚠️ **Change the admin password immediately** via Admin → Users → Edit.

---

## File Structure

```
/
├── index.php              Main repeater listing (public)
├── repeater.php           Repeater detail view (public)
├── conflicts.php          Conflict detection & management
├── map.php                Interactive map (requires coordinates)
├── export.php             CSV export
├── login.php              Authentication
├── logout.php
├── .htaccess              Apache security rules
├── includes/
│   ├── config.php         ← EDIT THIS: DB credentials
│   ├── header.php         Shared page header
│   └── footer.php         Shared page footer
├── admin/
│   ├── edit_repeater.php  Add/edit repeater form
│   ├── delete_repeater.php
│   ├── import.php         CSV bulk import
│   ├── rules.php          Coordination rules CRUD
│   └── users.php          User management
└── assets/
    ├── css/style.css
    └── js/app.js
```

---

## User Roles

| Role | Capabilities |
|------|--------------|
| **viewer** | Browse repeaters, view map, export CSV |
| **coordinator** | + Add/edit repeaters, import CSV, edit rules, run conflict scans |
| **admin** | + Delete records, manage users, full access |

---

## Coordination Rules

Navigate to **Admin → Coordination Rules** to configure:

| Setting | Description |
|---------|-------------|
| **Band Low/High MHz** | Frequency range this rule applies to |
| **Channel Step (kHz)** | Minimum channel spacing (e.g., 15 kHz for 2m) |
| **Channel Width (kHz)** | Maximum occupied bandwidth |
| **Co-Channel Min Miles** | Minimum distance between same-frequency repeaters |
| **Adjacent-Channel Min Miles** | Minimum distance between adjacent-channel repeaters |

Default rules follow ARRL band plans for 6m, 10m, 2m, 1.25m, 70cm, 33cm, and 23cm.

---

## Conflict Detection

1. Add GPS coordinates (decimal degrees) to repeaters via the edit form
2. Go to **Conflicts → Run Conflict Scan**
3. The system compares every repeater pair and flags:
   - **Co-channel:** same frequency, within minimum distance
   - **Adjacent-channel:** within 1 channel step, within minimum distance
   - Repeaters **without coordinates** are flagged based on frequency alone

Coordinators can mark conflicts as resolved with a note.

---

## Importing Data

Go to **Admin → Import** and upload a CSV. Supported modes:

- **Skip duplicates** — Only import new records (matched by callsign + output freq)
- **Update existing** — Update matching records, insert new ones
- **Replace ALL** — Clears database and reimports (use with caution!)

The CSV must follow ORSI column order (see the import page for full format guide).

---

## Adding GPS Coordinates (for Map & Distance Conflicts)

Edit each repeater and enter:
- **Latitude** — decimal degrees (e.g., `35.4675`)
- **Longitude** — decimal degrees (e.g., `-97.5164`)

Use [FCC Antenna Structure Registration](https://www.fcc.gov/antenna-structure-registration) or
[QRZ.com](https://www.qrz.com) to look up coordinates by callsign.

---

## Security Notes

- Change the default admin password immediately after installation
- Use HTTPS (install Let's Encrypt): `sudo apt install certbot python3-certbot-apache && sudo certbot --apache`
- The `.htaccess` blocks direct access to `includes/` and sensitive file types
- All user input is parameterized via PDO to prevent SQL injection
- Passwords are hashed with bcrypt (PHP `password_hash`)

---

## Backup

```bash
# Database backup
mysqldump -u repeater_user -p ok_repeater_coord > backup_$(date +%Y%m%d).sql

# Restore
mysql -u repeater_user -p ok_repeater_coord < backup_20251018.sql
```

---

## Support

For questions about the coordination system, contact your ORSI district coordinator.
For technical issues, check Apache error logs: `sudo tail -f /var/log/apache2/error.log`
