#!/bin/bash
# ORSI Repeater Coordination System — Installer
# Tested on Ubuntu 22.04 / 24.04

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[ "$EUID" -ne 0 ] && error "Please run as root: sudo bash install.sh"

echo ""
echo "========================================================"
echo "  ORSI Repeater Coordination System — Installer v1.0"
echo "========================================================"
echo ""

# ── Configuration ──────────────────────────────────────────
read -p "Web server domain (e.g. w5dro.com): " DOMAIN
read -p "Base path (e.g. /repeater_coord): " BASE_PATH
BASE_PATH=${BASE_PATH:-/repeater_coord}
read -p "MySQL root password: " MYSQL_ROOT_PW
read -p "DB name [ok_repeater_coord]: " DB_NAME; DB_NAME=${DB_NAME:-ok_repeater_coord}
read -p "DB user [repeater_user]: " DB_USER; DB_USER=${DB_USER:-repeater_user}
read -p "DB password: " DB_PASS
read -p "Web root [/var/www/${DOMAIN}]: " WEB_ROOT
WEB_ROOT=${WEB_ROOT:-/var/www/${DOMAIN}}
APP_DIR="${WEB_ROOT}${BASE_PATH}"

echo ""
info "Installing to: ${APP_DIR}"
echo ""

# ── Dependencies ───────────────────────────────────────────
info "Installing dependencies..."
apt-get update -qq
apt-get install -y -qq \
    apache2 \
    php8.1 php8.1-mysql php8.1-mbstring php8.1-xml php8.1-curl \
    mysql-server \
    postfix \
    splat \
    imagemagick \
    wget unzip curl

a2enmod rewrite 2>/dev/null || true
info "Dependencies installed"

# ── MySQL ──────────────────────────────────────────────────
info "Setting up MySQL..."
# Enable trigger creation
grep -q "log_bin_trust_function_creators" /etc/mysql/mysql.conf.d/mysqld.cnf || \
    echo "log_bin_trust_function_creators = 1" >> /etc/mysql/mysql.conf.d/mysqld.cnf
systemctl restart mysql

mysql -u root -p"${MYSQL_ROOT_PW}" << SQLEOF
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
FLUSH PRIVILEGES;
SQLEOF

info "Importing database..."
mysql -u root -p"${MYSQL_ROOT_PW}" ${DB_NAME} < orsi_database.sql

# Fix trigger definers
info "Fixing trigger definers..."
mysql -u root -p"${MYSQL_ROOT_PW}" ${DB_NAME} << SQLEOF
DROP TRIGGER IF EXISTS calc_erp_on_update;
DROP TRIGGER IF EXISTS calc_erp_on_insert;
CREATE DEFINER='${DB_USER}'@'localhost' TRIGGER calc_erp_on_update
BEFORE UPDATE ON repeaters FOR EACH ROW
SET NEW.erp_watts = CASE
    WHEN NEW.tx_power_watts IS NOT NULL AND NEW.tx_power_watts > 0
    THEN ROUND(NEW.tx_power_watts * POW(10,(COALESCE(NEW.antenna_gain_dbd,0)-COALESCE(NEW.feedline_loss_db,0))/10),3)
    ELSE NEW.erp_watts END;
CREATE DEFINER='${DB_USER}'@'localhost' TRIGGER calc_erp_on_insert
BEFORE INSERT ON repeaters FOR EACH ROW
SET NEW.erp_watts = CASE
    WHEN NEW.tx_power_watts IS NOT NULL AND NEW.tx_power_watts > 0
    THEN ROUND(NEW.tx_power_watts * POW(10,(COALESCE(NEW.antenna_gain_dbd,0)-COALESCE(NEW.feedline_loss_db,0))/10),3)
    ELSE NEW.erp_watts END;
SQLEOF
info "Database ready"

# ── Web files ──────────────────────────────────────────────
info "Installing web files..."
mkdir -p "${APP_DIR}"
cp -r repeater_coord/. "${APP_DIR}/"
mkdir -p "${APP_DIR}/splat_cache"
chown -R www-data:www-data "${APP_DIR}"
chmod -R 755 "${APP_DIR}"
chmod 777 "${APP_DIR}/splat_cache"

# Update config.php
CONFIG="${APP_DIR}/includes/config.php"
sed -i "s|define('DB_NAME'.*|define('DB_NAME', '${DB_NAME}');|" "$CONFIG"
sed -i "s|define('DB_USER'.*|define('DB_USER', '${DB_USER}');|" "$CONFIG"
sed -i "s|define('DB_PASS'.*|define('DB_PASS', '${DB_PASS}');|" "$CONFIG"
sed -i "s|define('BASE_PATH'.*|define('BASE_PATH', '${BASE_PATH}');|" "$CONFIG"
info "Web files installed"

# ── Apache ─────────────────────────────────────────────────
info "Configuring Apache..."
cat > "/etc/apache2/sites-available/${DOMAIN}.conf" << APACHEEOF
<VirtualHost *:80>
    ServerName ${DOMAIN}
    DocumentRoot ${WEB_ROOT}
    <Directory ${WEB_ROOT}>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}-error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}-access.log combined
</VirtualHost>
APACHEEOF
a2ensite "${DOMAIN}" 2>/dev/null || true
systemctl reload apache2
info "Apache configured"

# ── Postfix ────────────────────────────────────────────────
info "Configuring Postfix..."
postconf -e "inet_interfaces = loopback-only"
postconf -e "myhostname = ${DOMAIN}"
systemctl restart postfix
info "Postfix configured"

# ── SPLAT! ─────────────────────────────────────────────────
info "Setting up SPLAT!..."
mkdir -p /usr/local/share/splat/sdf
mkdir -p /usr/local/share/splat/sdf-hd
echo "www-data ALL=(ALL) NOPASSWD: /usr/bin/splat, /usr/bin/splat-hd, /usr/bin/convert" \
    > /etc/sudoers.d/splat
chmod 440 /etc/sudoers.d/splat

read -p "Download Oklahoma SRTM terrain tiles? (~500MB) [y/N]: " DL_TERRAIN
if [[ "$DL_TERRAIN" =~ ^[Yy]$ ]]; then
    info "Downloading terrain tiles..."
    for lat in 33 34 35 36; do
        for lon in 094 095 096 097 098 099 100 101 102 103; do
            hgt="N${lat}W${lon}.hgt"
            echo -n "  ${hgt}... "
            wget -q "https://s3.amazonaws.com/elevation-tiles-prod/skadi/N${lat}/N${lat}W${lon}.hgt.gz" \
                -O /tmp/${hgt}.gz && \
            gunzip -f /tmp/${hgt}.gz && \
            srtm2sdf /tmp/${hgt} 2>/dev/null && \
            mv /tmp/*.sdf /usr/local/share/splat/sdf/ 2>/dev/null && \
            rm -f /tmp/${hgt} && echo "OK" || echo "FAILED"
        done
    done
    info "Terrain tiles: $(ls /usr/local/share/splat/sdf/ | wc -l) installed"
fi

# ── Cron ───────────────────────────────────────────────────
info "Installing cron job..."
CRON_LINE="0 8 * * * php ${APP_DIR}/admin/send_renewals.php >> /var/log/orsi_renewals.log 2>&1"
( crontab -l 2>/dev/null | grep -v "send_renewals"; echo "$CRON_LINE" ) | crontab -
info "Cron installed"

# ── Self test ──────────────────────────────────────────────
echo ""
echo "========================================================"
info "Self-test..."
echo "========================================================"
php -r "echo 'PHP ' . PHP_VERSION . ': OK' . PHP_EOL;"
php -r "
try {
    \$db = new PDO('mysql:host=localhost;dbname=${DB_NAME}', '${DB_USER}', '${DB_PASS}');
    \$c = \$db->query('SELECT COUNT(*) FROM repeaters')->fetchColumn();
    echo 'MySQL: OK (' . \$c . ' repeaters)' . PHP_EOL;
} catch(Exception \$e) { echo 'MySQL: FAILED - ' . \$e->getMessage() . PHP_EOL; }
"
curl -s -o /dev/null -w "Apache: HTTP %{http_code}\n" "http://localhost${BASE_PATH}/"
systemctl is-active postfix > /dev/null && echo "Postfix: OK" || echo "Postfix: FAILED"
which splat > /dev/null && echo "SPLAT!: OK" || echo "SPLAT!: NOT FOUND"
which convert > /dev/null && echo "ImageMagick: OK" || echo "ImageMagick: NOT FOUND"

echo ""
echo "========================================================"
echo -e "${GREEN}  Installation complete!${NC}"
echo "========================================================"
echo ""
echo "  URL:      http://${DOMAIN}${BASE_PATH}/"
echo "  Login:    http://${DOMAIN}${BASE_PATH}/login.php"
echo ""
echo "  Post-install checklist:"
echo "  1. Add SPF DNS record: v=spf1 ip4:$(curl -s ifconfig.me 2>/dev/null) ~all"
echo "  2. Admin → Users: assign districts to coordinators"
echo "  3. Admin → Rules → NOPC: update neighboring state emails"
echo "  4. Test email: Admin → Test Email"
echo "  5. Renewal dry-run: Admin → Renewals (dry run)"
echo ""
